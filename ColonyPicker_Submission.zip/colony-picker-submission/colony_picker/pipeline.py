from __future__ import annotations

import dataclasses
import re
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

from .config import SelectionConfig
from .measure import measure_instances
from .output import write_json_atomic, write_png_atomic, write_summary
from .preprocess import detect_plate_roi, prepare_input
from .selection import evaluate_instances
from .visualize import render_result


@dataclass
class AnalysisResult:
    source_path: Path
    status: str
    colony_count: int = 0
    pickable_count: int = 0
    output_dir: Path | None = None
    result_image: Path | None = None
    result_json: Path | None = None
    error: str = ""

    def summary_row(self) -> dict:
        return {
            "source": str(self.source_path),
            "status": self.status,
            "colony_count": self.colony_count,
            "pickable_count": self.pickable_count,
            "result_image": str(self.result_image or ""),
            "result_json": str(self.result_json or ""),
            "error": self.error,
        }


def read_image(path: Path) -> np.ndarray:
    try:
        data = np.fromfile(path, dtype=np.uint8)
    except OSError as exc:
        raise FileNotFoundError(f"Cannot read image: {path}") from exc
    image = cv2.imdecode(data, cv2.IMREAD_COLOR) if data.size else None
    if image is None:
        raise ValueError(f"Unsupported or invalid image: {path}")
    return image


def _safe_stem(stem: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", stem).strip(" .")
    return cleaned or "image"


def _unique_output_dir(root: Path, stem: str) -> Path:
    base = root / _safe_stem(stem)
    candidate = base
    suffix = 2
    while candidate.exists():
        candidate = root / f"{base.name}_{suffix}"
        suffix += 1
    candidate.mkdir(parents=True)
    return candidate


def analyze_image(
    path: Path,
    output_dir: Path,
    segmenter,
    selection_config: SelectionConfig | None = None,
) -> AnalysisResult:
    source = Path(path)
    image = read_image(source)
    roi = detect_plate_roi(image)
    prepared = prepare_input(image, roi)
    raw_instances = segmenter.predict(prepared)
    measured = measure_instances(raw_instances, roi)
    instances = evaluate_instances(measured, selection_config or SelectionConfig())
    rendered = render_result(image, instances)
    destination = _unique_output_dir(Path(output_dir), source.stem)
    result_image = destination / "result.png"
    result_json = destination / "result.json"
    write_png_atomic(result_image, rendered)
    payload = {
        "source": str(source),
        "original_size": [int(image.shape[1]), int(image.shape[0])],
        "roi": dataclasses.asdict(roi),
        "inference": {
            "roi_size": [roi.width, roi.height],
            "padded_size": [int(prepared.padded_image.shape[1]), int(prepared.padded_image.shape[0])],
            "pad_right": prepared.pad_right,
            "pad_bottom": prepared.pad_bottom,
            "native_scale": True,
        },
        "colony_count": len(instances),
        "pickable_count": sum(item.pickable for item in instances),
        "instances": [item.to_dict() for item in instances],
    }
    write_json_atomic(result_json, payload)
    return AnalysisResult(
        source_path=source,
        status="ok",
        colony_count=len(instances),
        pickable_count=sum(item.pickable for item in instances),
        output_dir=destination,
        result_image=result_image,
        result_json=result_json,
    )


def analyze_batch(paths: list[Path], output_dir: Path, segmenter) -> list[AnalysisResult]:
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    results: list[AnalysisResult] = []
    for path in paths:
        try:
            result = analyze_image(Path(path), root, segmenter)
        except Exception as exc:
            result = AnalysisResult(Path(path), "error", error=f"{type(exc).__name__}: {exc}")
        results.append(result)
        write_summary(root / "summary.csv", [item.summary_row() for item in results])
    if not paths:
        write_summary(root / "summary.csv", [])
    return results
