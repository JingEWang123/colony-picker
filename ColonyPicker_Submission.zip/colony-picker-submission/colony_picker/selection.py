from __future__ import annotations

import math

import numpy as np

from .config import SelectionConfig
from .measure import ColonyInstance


def _score(instance: ColonyInstance) -> float:
    neighbor = 1.0 if not math.isfinite(instance.nearest_colony_clearance) else min(instance.nearest_colony_clearance / 20.0, 1.0)
    value = (
        0.35 * np.clip(instance.confidence, 0.0, 1.0)
        + 0.20 * np.clip(instance.circularity, 0.0, 1.0)
        + 0.15 * np.clip(instance.solidity, 0.0, 1.0)
        + 0.10 * np.clip(instance.plate_edge_clearance / 20.0, 0.0, 1.0)
        + 0.10 * neighbor
        + 0.10 * np.clip(instance.inner_radius / 10.0, 0.0, 1.0)
    )
    return round(float(value * 100.0), 3)


def evaluate_instances(instances: list[ColonyInstance], config: SelectionConfig) -> list[ColonyInstance]:
    for instance in instances:
        reasons = []
        if instance.confidence < config.min_confidence:
            reasons.append("low_confidence")
        if instance.area < config.min_area:
            reasons.append("too_small")
        if instance.plate_edge_clearance < config.min_plate_clearance:
            reasons.append("plate_edge")
        if instance.nearest_colony_clearance < config.min_neighbor_clearance:
            reasons.append("too_close")
        if instance.inner_radius < config.min_inner_radius:
            reasons.append("inner_safe_area")
        if instance.circularity < config.min_circularity:
            reasons.append("suspected_merged_circularity")
        if instance.solidity < config.min_solidity:
            reasons.append("suspected_merged_solidity")
        instance.reasons = reasons
        instance.pickable = not reasons
        instance.pick_score = _score(instance) if instance.pickable else 0.0
    ordered = sorted(instances, key=lambda item: (not item.pickable, -item.pick_score, -item.confidence))
    for index, instance in enumerate(ordered, start=1):
        instance.id = index
    return ordered
