from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class InferenceConfig:
    stride: int = 32
    confidence: float = 0.35
    iou: float = 0.70
    mask_threshold: float = 0.50
    max_detections: int = 1000


@dataclass(frozen=True)
class SelectionConfig:
    min_confidence: float = 0.35
    min_area: float = 20.0
    min_plate_clearance: float = 8.0
    min_neighbor_clearance: float = 6.0
    min_inner_radius: float = 3.0
    min_circularity: float = 0.45
    min_solidity: float = 0.75

