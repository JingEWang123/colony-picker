from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from .config import InferenceConfig


@dataclass
class RawInstance:
    box_xyxy: tuple[float, float, float, float]
    confidence: float
    mask: np.ndarray


def _prediction_rows(prediction: np.ndarray, mask_channels: int) -> np.ndarray:
    rows = np.asarray(prediction, dtype=np.float32)
    if rows.ndim == 3:
        if rows.shape[0] != 1:
            raise ValueError(f"Only batch size 1 is supported, got {rows.shape}")
        rows = rows[0]
    if rows.ndim != 2:
        raise ValueError(f"Unexpected prediction shape {rows.shape}")
    minimum_features = 5 + mask_channels
    if rows.shape[0] >= minimum_features and (rows.shape[0] <= rows.shape[1] or rows.shape[1] < minimum_features):
        rows = rows.T
    if rows.shape[1] < minimum_features:
        raise ValueError(f"Prediction has too few features: {rows.shape}")
    return rows


def _sigmoid(values: np.ndarray) -> np.ndarray:
    values = np.clip(values, -30.0, 30.0)
    return 1.0 / (1.0 + np.exp(-values))


def decode_yolo_seg(
    outputs: list[np.ndarray] | tuple[np.ndarray, ...],
    padded_shape: tuple[int, int],
    roi_shape: tuple[int, int],
    config: InferenceConfig,
) -> list[RawInstance]:
    if len(outputs) < 2:
        raise ValueError("YOLO segmentation export must return detections and prototypes")
    prototype = np.asarray(outputs[1], dtype=np.float32)
    if prototype.ndim == 4:
        if prototype.shape[0] != 1:
            raise ValueError("Only batch size 1 is supported")
        prototype = prototype[0]
    if prototype.ndim != 3:
        raise ValueError(f"Unexpected prototype shape {prototype.shape}")
    mask_channels = prototype.shape[0]
    rows = _prediction_rows(outputs[0], mask_channels)
    class_count = rows.shape[1] - 4 - mask_channels
    if class_count < 1:
        raise ValueError(f"Could not infer class channels from {rows.shape}")

    class_scores = rows[:, 4 : 4 + class_count]
    confidences = class_scores.max(axis=1)
    keep = confidences >= config.confidence
    if not np.any(keep):
        return []
    rows = rows[keep]
    confidences = confidences[keep]
    coefficients = rows[:, 4 + class_count :]

    xywh = rows[:, :4]
    boxes_xyxy = np.column_stack(
        (
            xywh[:, 0] - xywh[:, 2] / 2.0,
            xywh[:, 1] - xywh[:, 3] / 2.0,
            xywh[:, 0] + xywh[:, 2] / 2.0,
            xywh[:, 1] + xywh[:, 3] / 2.0,
        )
    )
    nms_boxes = [
        [float(x1), float(y1), float(max(0.0, x2 - x1)), float(max(0.0, y2 - y1))]
        for x1, y1, x2, y2 in boxes_xyxy
    ]
    indices = cv2.dnn.NMSBoxes(
        nms_boxes,
        confidences.astype(float).tolist(),
        score_threshold=config.confidence,
        nms_threshold=config.iou,
        top_k=config.max_detections,
    )
    if len(indices) == 0:
        return []
    selected = np.asarray(indices).reshape(-1).astype(int)

    padded_height, padded_width = padded_shape
    roi_height, roi_width = roi_shape
    flat_proto = prototype.reshape(mask_channels, -1)
    decoded: list[RawInstance] = []
    for index in selected:
        logits = coefficients[index] @ flat_proto
        small_mask = _sigmoid(logits.reshape(prototype.shape[1:]))
        native_mask = cv2.resize(small_mask, (padded_width, padded_height), interpolation=cv2.INTER_LINEAR)
        x1, y1, x2, y2 = boxes_xyxy[index]
        left = max(0, min(padded_width, int(np.floor(x1))))
        top = max(0, min(padded_height, int(np.floor(y1))))
        right = max(0, min(padded_width, int(np.ceil(x2))))
        bottom = max(0, min(padded_height, int(np.ceil(y2))))
        cropped = np.zeros((padded_height, padded_width), dtype=np.uint8)
        if right > left and bottom > top:
            cropped[top:bottom, left:right] = (
                native_mask[top:bottom, left:right] >= config.mask_threshold
            ).astype(np.uint8)
        roi_mask = cropped[:roi_height, :roi_width]
        clipped_box = (
            float(np.clip(x1, 0, roi_width)),
            float(np.clip(y1, 0, roi_height)),
            float(np.clip(x2, 0, roi_width)),
            float(np.clip(y2, 0, roi_height)),
        )
        decoded.append(RawInstance(clipped_box, float(confidences[index]), roi_mask))
    return decoded

