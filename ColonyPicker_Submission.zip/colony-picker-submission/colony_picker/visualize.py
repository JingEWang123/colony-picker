from __future__ import annotations

import math

import cv2
import numpy as np

from .measure import ColonyInstance


def label_font_scale(image_shape: tuple[int, int], instance_count: int) -> float:
    base = min(0.8, max(0.35, min(image_shape[:2]) / 2400.0))
    density = min(1.0, math.sqrt(40.0 / max(1, instance_count)))
    return max(0.30, base * density)


def render_result(image: np.ndarray, instances: list[ColonyInstance]) -> np.ndarray:
    rendered = image.copy()
    overlay = rendered.copy()
    for instance in instances:
        color = (0, 190, 0) if instance.pickable else (0, 0, 220)
        cv2.drawContours(overlay, [instance.contour], -1, color, thickness=cv2.FILLED)
    rendered = cv2.addWeighted(overlay, 0.28, rendered, 0.72, 0.0)
    font_scale = label_font_scale(image.shape[:2], len(instances))
    thickness = max(1, round(font_scale * 2))
    for instance in instances:
        color = (0, 190, 0) if instance.pickable else (0, 0, 220)
        cv2.drawContours(rendered, [instance.contour], -1, color, thickness=max(1, thickness))
        if instance.pickable:
            label = f"ID {instance.id} score {instance.pick_score:.1f}"
        else:
            reason = ",".join(instance.reasons[:2]) if instance.reasons else "rejected"
            label = f"ID {instance.id} {reason}"
        anchor = (int(instance.box_xyxy[0]), max(15, int(instance.box_xyxy[1]) - 4))
        cv2.putText(rendered, label, anchor, cv2.FONT_HERSHEY_SIMPLEX, font_scale, color, thickness, cv2.LINE_AA)
        cv2.circle(rendered, instance.pick_point, max(3, thickness + 2), (0, 255, 255), -1)
    return rendered
