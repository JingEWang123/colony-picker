from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass(frozen=True)
class PlateROI:
    x: int
    y: int
    width: int
    height: int
    center_x: float
    center_y: float
    radius: float
    detected: bool
    method: str

    @property
    def center_in_roi(self) -> tuple[float, float]:
        return self.center_x - self.x, self.center_y - self.y


@dataclass
class PreparedInput:
    tensor: np.ndarray
    roi_image: np.ndarray
    padded_image: np.ndarray
    roi: PlateROI
    original_shape: tuple[int, int]
    pad_bottom: int
    pad_right: int

    def point_to_original(self, point: tuple[float, float]) -> tuple[int, int]:
        return int(round(point[0] + self.roi.x)), int(round(point[1] + self.roi.y))

    def mask_to_original(self, mask: np.ndarray) -> np.ndarray:
        height, width = self.original_shape
        mapped = np.zeros((height, width), dtype=np.uint8)
        roi_mask = (mask[: self.roi.height, : self.roi.width] > 0).astype(np.uint8)
        mapped[self.roi.y : self.roi.y + self.roi.height, self.roi.x : self.roi.x + self.roi.width] = roi_mask
        return mapped


def detect_plate_roi(image: np.ndarray, max_detection_size: int = 1600) -> PlateROI:
    if image is None or image.ndim != 3 or image.size == 0:
        raise ValueError("Expected a non-empty BGR image")
    height, width = image.shape[:2]
    scale = min(1.0, max_detection_size / max(height, width))
    if scale < 1.0:
        sample = cv2.resize(image, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    else:
        sample = image
    gray = cv2.cvtColor(sample, cv2.COLOR_BGR2GRAY)
    gray = cv2.medianBlur(gray, 9)
    sh, sw = gray.shape
    minimum = min(sh, sw)
    circles = cv2.HoughCircles(
        gray,
        cv2.HOUGH_GRADIENT,
        dp=1.2,
        minDist=max(20, minimum // 2),
        param1=100,
        param2=40,
        minRadius=max(10, int(minimum * 0.25)),
        maxRadius=max(12, int(minimum * 0.58)),
    )
    candidates: list[tuple[float, float, float, float]] = []
    if circles is not None:
        image_center = np.array([sw / 2.0, sh / 2.0], dtype=np.float32)
        for cx, cy, radius in circles[0]:
            center_distance = float(np.linalg.norm(np.array([cx, cy]) - image_center))
            if center_distance > max(sw, sh) * 0.38:
                continue
            score = float(radius) - center_distance * 0.45
            candidates.append((score, float(cx), float(cy), float(radius)))
    if not candidates:
        return PlateROI(
            0,
            0,
            width,
            height,
            (width - 1) / 2.0,
            (height - 1) / 2.0,
            min(width, height) * 0.48,
            False,
            "full_image_fallback",
        )

    _, cx, cy, radius = max(candidates, key=lambda item: item[0])
    cx, cy, radius = cx / scale, cy / scale, radius / scale
    crop_radius = radius * 1.04
    x0 = max(0, int(np.floor(cx - crop_radius)))
    y0 = max(0, int(np.floor(cy - crop_radius)))
    x1 = min(width, int(np.ceil(cx + crop_radius)))
    y1 = min(height, int(np.ceil(cy + crop_radius)))
    return PlateROI(x0, y0, x1 - x0, y1 - y0, cx, cy, radius, True, "hough_circle")


def prepare_input(image: np.ndarray, roi: PlateROI, stride: int = 32) -> PreparedInput:
    if stride <= 0:
        raise ValueError("stride must be positive")
    roi_image = image[roi.y : roi.y + roi.height, roi.x : roi.x + roi.width].copy()
    if roi_image.size == 0:
        raise ValueError("ROI does not intersect the image")
    height, width = roi_image.shape[:2]
    pad_bottom = (-height) % stride
    pad_right = (-width) % stride
    padded = cv2.copyMakeBorder(
        roi_image,
        0,
        pad_bottom,
        0,
        pad_right,
        cv2.BORDER_CONSTANT,
        value=(114, 114, 114),
    )
    rgb = cv2.cvtColor(padded, cv2.COLOR_BGR2RGB)
    tensor = np.ascontiguousarray(rgb.transpose(2, 0, 1)[None], dtype=np.float32) / 255.0
    return PreparedInput(
        tensor=tensor,
        roi_image=roi_image,
        padded_image=padded,
        roi=roi,
        original_shape=image.shape[:2],
        pad_bottom=pad_bottom,
        pad_right=pad_right,
    )
