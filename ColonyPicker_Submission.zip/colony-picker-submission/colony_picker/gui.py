from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .inference import OnnxSegmenter
from .pipeline import AnalysisResult, analyze_batch


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png"}


def normalize_input_paths(values) -> list[Path]:
    result: list[Path] = []
    seen: set[str] = set()
    for value in values:
        path = Path(str(value))
        if path.suffix.lower() not in IMAGE_EXTENSIONS:
            continue
        key = str(path).replace("\\", "/").casefold()
        if key not in seen:
            seen.add(key)
            result.append(path)
    return result


def parse_drop_files(payload: str) -> list[Path]:
    try:
        values = tk.Tcl().splitlist(payload)
    except tk.TclError:
        values = [payload]
    return normalize_input_paths(values)


def create_root():
    try:
        from tkinterdnd2 import TkinterDnD

        return TkinterDnD.Tk()
    except Exception:
        return tk.Tk()


def _open_directory(path: Path) -> None:
    if sys.platform == "win32":
        os.startfile(path)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


class ColonyPickerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ColonyPicker")
        self.root.geometry("1100x720")
        self.paths: list[Path] = []
        self.results: list[AnalysisResult] = []
        self.events: queue.Queue = queue.Queue()
        self.output_dir: Path | None = None
        self.preview_image = None
        self._build_ui()
        self._enable_drop()
        self.root.after(100, self._poll_events)

    def _build_ui(self):
        toolbar = ttk.Frame(self.root, padding=8)
        toolbar.pack(fill=tk.X)
        ttk.Button(toolbar, text="选择图片", command=self._choose_files).pack(side=tk.LEFT, padx=3)
        ttk.Button(toolbar, text="清空", command=self._clear).pack(side=tk.LEFT, padx=3)
        self.start_button = ttk.Button(toolbar, text="开始分析", command=self._start)
        self.start_button.pack(side=tk.LEFT, padx=12)
        self.open_button = ttk.Button(toolbar, text="打开输出目录", command=self._open_output, state=tk.DISABLED)
        self.open_button.pack(side=tk.LEFT, padx=3)

        content = ttk.Panedwindow(self.root, orient=tk.HORIZONTAL)
        content.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)
        left = ttk.Frame(content, width=320)
        right = ttk.Frame(content)
        content.add(left, weight=1)
        content.add(right, weight=3)

        ttk.Label(left, text="图片列表（可拖入 JPG/PNG）").pack(anchor=tk.W)
        self.listbox = tk.Listbox(left, selectmode=tk.EXTENDED)
        self.listbox.pack(fill=tk.BOTH, expand=True, pady=4)
        self.listbox.bind("<<ListboxSelect>>", self._show_selected)

        self.preview = ttk.Label(right, text="分析结果预览", anchor=tk.CENTER)
        self.preview.pack(fill=tk.BOTH, expand=True)
        stats = ttk.Frame(right, padding=8)
        stats.pack(fill=tk.X)
        self.count_label = ttk.Label(stats, text="Colony: 0    Pickable: 0")
        self.count_label.pack(side=tk.LEFT)
        self.status_label = ttk.Label(stats, text="等待添加图片")
        self.status_label.pack(side=tk.RIGHT)

    def _enable_drop(self):
        try:
            from tkinterdnd2 import DND_FILES

            self.listbox.drop_target_register(DND_FILES)
            self.listbox.dnd_bind("<<Drop>>", self._on_drop)
        except Exception:
            pass

    def _on_drop(self, event):
        self._add_paths(parse_drop_files(event.data))

    def _choose_files(self):
        values = filedialog.askopenfilenames(
            title="选择培养皿图片",
            filetypes=[("Images", "*.jpg *.jpeg *.png"), ("All files", "*.*")],
        )
        self._add_paths(normalize_input_paths(values))

    def _add_paths(self, new_paths: list[Path]):
        combined = normalize_input_paths([*self.paths, *new_paths])
        self.paths = combined
        self.listbox.delete(0, tk.END)
        for path in self.paths:
            self.listbox.insert(tk.END, str(path))
        self.status_label.config(text=f"已添加 {len(self.paths)} 张图片")

    def _clear(self):
        self.paths.clear()
        self.results.clear()
        self.listbox.delete(0, tk.END)
        self.preview.config(image="", text="分析结果预览")
        self.count_label.config(text="Colony: 0    Pickable: 0")

    def _start(self):
        if not self.paths:
            messagebox.showinfo("ColonyPicker", "请先添加 JPG 或 PNG 图片。")
            return
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.output_dir = Path.home() / "Documents" / "ColonyPicker_Output" / timestamp
        self.start_button.config(state=tk.DISABLED)
        self.status_label.config(text="正在分析…")
        threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        try:
            segmenter = OnnxSegmenter()
            results = analyze_batch(self.paths, self.output_dir, segmenter)
            self.events.put(("done", results))
        except Exception as exc:
            self.events.put(("fatal", f"{type(exc).__name__}: {exc}"))

    def _poll_events(self):
        try:
            kind, payload = self.events.get_nowait()
        except queue.Empty:
            self.root.after(100, self._poll_events)
            return
        self.start_button.config(state=tk.NORMAL)
        if kind == "fatal":
            self.status_label.config(text="分析失败")
            messagebox.showerror("ColonyPicker", payload)
        else:
            self.results = payload
            ok_count = sum(item.status == "ok" for item in self.results)
            self.status_label.config(text=f"完成 {ok_count}/{len(self.results)}")
            self.open_button.config(state=tk.NORMAL)
            if self.results:
                self.listbox.selection_clear(0, tk.END)
                self.listbox.selection_set(0)
                self._show_result(0)
        self.root.after(100, self._poll_events)

    def _show_selected(self, _event=None):
        selected = self.listbox.curselection()
        if selected and self.results:
            self._show_result(selected[0])

    def _show_result(self, index: int):
        if index >= len(self.results):
            return
        result = self.results[index]
        self.count_label.config(text=f"Colony: {result.colony_count}    Pickable: {result.pickable_count}")
        if result.status != "ok" or not result.result_image:
            self.preview.config(image="", text=result.error or "分析失败")
            return
        photo = tk.PhotoImage(file=str(result.result_image))
        factor = max(1, (photo.width() + 699) // 700, (photo.height() + 549) // 550)
        if factor > 1:
            photo = photo.subsample(factor, factor)
        self.preview_image = photo
        self.preview.config(image=photo, text="")

    def _open_output(self):
        if self.output_dir:
            _open_directory(self.output_dir)


def launch_gui() -> None:
    root = create_root()
    ColonyPickerApp(root)
    root.mainloop()

