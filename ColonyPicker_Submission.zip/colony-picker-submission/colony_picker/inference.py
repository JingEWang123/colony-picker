from __future__ import annotations

from pathlib import Path

from .config import InferenceConfig
from .postprocess import RawInstance, decode_yolo_seg
from .preprocess import PreparedInput
from .resources import model_path


class OnnxSegmenter:
    def __init__(self, model: Path | None = None, config: InferenceConfig | None = None):
        import onnxruntime as ort

        self.config = config or InferenceConfig()
        self.model = Path(model) if model is not None else model_path()
        if not self.model.is_file():
            raise FileNotFoundError(f"ONNX model not found: {self.model}")
        self.session = ort.InferenceSession(str(self.model), providers=["CPUExecutionProvider"])
        self.input_name = self.session.get_inputs()[0].name

    def predict(self, prepared: PreparedInput) -> list[RawInstance]:
        outputs = self.session.run(None, {self.input_name: prepared.tensor})
        return decode_yolo_seg(
            outputs,
            padded_shape=prepared.padded_image.shape[:2],
            roi_shape=prepared.roi_image.shape[:2],
            config=self.config,
        )
