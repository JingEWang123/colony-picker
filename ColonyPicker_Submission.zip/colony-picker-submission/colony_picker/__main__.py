from __future__ import annotations

import argparse
import multiprocessing
from pathlib import Path

from .gui import launch_gui
from .inference import OnnxSegmenter


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="ColonyPicker desktop application")
    parser.add_argument("--smoke", action="store_true", help="Load the bundled model without opening the GUI")
    parser.add_argument("--model", type=Path, default=None, help="Override the bundled ONNX model")
    args = parser.parse_args(argv)
    if args.smoke:
        segmenter = OnnxSegmenter(args.model)
        print(f"ColonyPicker smoke OK: {segmenter.model}")
        return 0
    launch_gui()
    return 0


if __name__ == "__main__":
    multiprocessing.freeze_support()
    raise SystemExit(main())

