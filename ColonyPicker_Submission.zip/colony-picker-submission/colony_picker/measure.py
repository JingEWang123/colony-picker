from __future__ import annotations

import math
from dataclasses import dataclass, field

import cv2
import numpy as np

from .postprocess import RawInstance
from .preprocess import PlateROI


@dataclass
class ColonyInstance:
    id: int
    confidence: float
    area: float
    equivalent_radius: float
    circularity: float
    solidity: float
    plate_edge_clearance: float
    nearest_colony_clearance: float
    pick_point: tuple[int, int]
    inner_radius: float
    box_xyxy: tuple[float, float, float, float]
    centroid: tuple[float, float]
    contour: np.ndarray = field(repr=False)
    pickable: bool = False
    pick_score: float = 0.0
    reasons: list[str] = field(default_factory=list)

    @classmethod
    def for_test(cls, **overrides):
        values = {
            "id": 0,
            "confidence": 0.8,
            "area": 100.0,
            "equivalent_radius": math.sqrt(100.0 / math.pi),
            "circularity": 0.9,
            "solidity": 0.9,
            "plate_edge_clearance": 30.0,
            "nearest_colony_clearance": 30.0,
            "pick_point": (10, 10),
            "inner_radius": 6.0,
            "box_xyxy": (0.0, 0.0, 20.0, 20.0),
            "centroid": (10.0, 10.0),
            "contour": np.empty((0, 1, 2), dtype=np.int32),
        }
        values.update(overrides)
        return cls(**values)

    def to_dict(self) -> dict:
        nearest = self.nearest_colony_clearance
        return {
            "id": self.id,
            "confidence": round(self.confidence, 6),
            "area": round(self.area, 3),
            "equivalent_radius": round(self.equivalent_radius, 3),
            "circularity": round(self.circularity, 6),
            "solidity": round(self.solidity, 6),
            "plate_edge_clearance": round(self.plate_edge_clearance, 3),
            "nearest_colony_clearance": None if not math.isfinite(nearest) else round(nearest, 3),
            "pick_point": [int(self.pick_point[0]), int(self.pick_point[1])],
            "inner_radius": round(self.inner_radius, 3),
            "box_xyxy": [round(value, 3) for value in self.box_xyxy],
            "centroid": [round(value, 3) for value in self.centroid],
            "polygon": [[int(x), int(y)] for x, y in self.contour.reshape(-1, 2)],
            "pickable": self.pickable,
            "pick_score": round(self.pick_score, 3),
            "reasons": list(self.reasons),
        }


def _largest_contour(mask: np.ndarray) -> np.ndarray | None:
    contours, _ = cv2.findContours((mask > 0).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return max(contours, key=cv2.contourArea) if contours else None


def _pick_point(mask: np.ndarray, offset: tuple[int, int]) -> tuple[tuple[int, int], float]:
    x, y, width, height = cv2.boundingRect((mask > 0).astype(np.uint8))
    crop = (mask[y : y + height, x : x + width] > 0).astype(np.uint8)
    distance = cv2.distanceTransform(crop, cv2.DIST_L2, 5)
    _, maximum, _, location = cv2.minMaxLoc(distance)
    return (offset[0] + x + location[0], offset[1] + y + location[1]), float(maximum)


def _contour_clearance(first: ColonyInstance, second: ColonyInstance) -> float:
    first_hull = cv2.convexHull(first.contour).astype(np.float32)
    second_hull = cv2.convexHull(second.contour).astype(np.float32)
    overlap_area, _ = cv2.intersectConvexConvex(first_hull, second_hull)
    if overlap_area > 0:
        return 0.0
    a = cv2.approxPolyDP(first.contour, 1.0, True).reshape(-1, 2).astype(np.float32)
    b = cv2.approxPolyDP(second.contour, 1.0, True).reshape(-1, 2).astype(np.float32)
    if len(a) == 0 or len(b) == 0:
        return math.inf
    differences = a[:, None, :] - b[None, :, :]
    return float(np.sqrt(np.sum(differences * differences, axis=2)).min())


def measure_instances(raw_instances: list[RawInstance], roi: PlateROI) -> list[ColonyInstance]:
    measured: list[ColonyInstance] = []
    roi_center = np.array(roi.center_in_roi, dtype=np.float32)
    for raw in raw_instances:
        contour_roi = _largest_contour(raw.mask)
        if contour_roi is None or cv2.contourArea(contour_roi) <= 0:
            continue
        area = float(cv2.contourArea(contour_roi))
        perimeter = float(cv2.arcLength(contour_roi, True))
        hull_area = float(cv2.contourArea(cv2.convexHull(contour_roi)))
        circularity = 4.0 * math.pi * area / (perimeter * perimeter) if perimeter > 0 else 0.0
        solidity = area / hull_area if hull_area > 0 else 0.0
        moments = cv2.moments(contour_roi)
        centroid_roi = (
            moments["m10"] / moments["m00"],
            moments["m01"] / moments["m00"],
        )
        contour_points = contour_roi.reshape(-1, 2).astype(np.float32)
        furthest = float(np.linalg.norm(contour_points - roi_center[None, :], axis=1).max())
        plate_clearance = roi.radius - furthest
        contour_original = contour_roi.copy()
        contour_original[:, 0, 0] += roi.x
        contour_original[:, 0, 1] += roi.y
        cleaned_mask = np.zeros_like(raw.mask, dtype=np.uint8)
        cv2.drawContours(cleaned_mask, [contour_roi], -1, 1, thickness=cv2.FILLED)
        pick_point, inner_radius = _pick_point(cleaned_mask, (roi.x, roi.y))
        x1, y1, x2, y2 = raw.box_xyxy
        measured.append(
            ColonyInstance(
                id=0,
                confidence=raw.confidence,
                area=area,
                equivalent_radius=math.sqrt(area / math.pi),
                circularity=circularity,
                solidity=solidity,
                plate_edge_clearance=plate_clearance,
                nearest_colony_clearance=math.inf,
                pick_point=pick_point,
                inner_radius=inner_radius,
                box_xyxy=(x1 + roi.x, y1 + roi.y, x2 + roi.x, y2 + roi.y),
                centroid=(centroid_roi[0] + roi.x, centroid_roi[1] + roi.y),
                contour=contour_original,
            )
        )
    for first_index in range(len(measured)):
        for second_index in range(first_index + 1, len(measured)):
            clearance = _contour_clearance(measured[first_index], measured[second_index])
            measured[first_index].nearest_colony_clearance = min(
                measured[first_index].nearest_colony_clearance, clearance
            )
            measured[second_index].nearest_colony_clearance = min(
                measured[second_index].nearest_colony_clearance, clearance
            )
    return measured
