"""ColonyPicker native-scale ONNX instance-segmentation runtime."""

__version__ = "1.0.0"

