import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from colony_picker.config import InferenceConfig, SelectionConfig
from colony_picker.resources import resource_path


class RuntimeFoundationTests(unittest.TestCase):
    def test_default_thresholds_are_stable(self):
        inference = InferenceConfig()
        selection = SelectionConfig()
        self.assertEqual((inference.stride, inference.confidence, inference.iou, inference.mask_threshold), (32, 0.35, 0.70, 0.50))
        self.assertEqual(
            (
                selection.min_area,
                selection.min_plate_clearance,
                selection.min_neighbor_clearance,
                selection.min_inner_radius,
                selection.min_circularity,
                selection.min_solidity,
            ),
            (20.0, 8.0, 6.0, 3.0, 0.45, 0.75),
        )

    def test_resource_path_uses_project_root_in_source_tree(self):
        path = resource_path("assets/best.onnx")
        self.assertEqual(path, Path(__file__).resolve().parents[1] / "assets" / "best.onnx")

    def test_resource_path_uses_pyinstaller_meipass(self):
        with patch.object(sys, "_MEIPASS", "/tmp/frozen-app", create=True):
            self.assertEqual(resource_path("assets/best.onnx"), Path("/tmp/frozen-app/assets/best.onnx"))


if __name__ == "__main__":
    unittest.main()
