import unittest

import numpy as np

from colony_picker.config import InferenceConfig
from colony_picker.postprocess import decode_yolo_seg


def synthetic_outputs(layout="channels_first", duplicate=False):
    rows = [
        [4.0, 4.0, 4.0, 4.0, 0.90, 10.0],
        [4.0, 4.0, 4.0, 4.0, 0.80 if duplicate else 0.10, 10.0],
    ]
    prediction = np.asarray(rows, dtype=np.float32)
    if layout == "channels_first":
        prediction = prediction.T[None]
    else:
        prediction = prediction[None]
    prototype = np.ones((1, 1, 2, 2), dtype=np.float32)
    return [prediction, prototype]


class OnnxPostprocessTests(unittest.TestCase):
    def test_decodes_channels_first_and_removes_padding(self):
        instances = decode_yolo_seg(
            synthetic_outputs("channels_first"),
            padded_shape=(8, 8),
            roi_shape=(6, 7),
            config=InferenceConfig(),
        )
        self.assertEqual(len(instances), 1)
        self.assertEqual(instances[0].mask.shape, (6, 7))
        self.assertEqual(instances[0].box_xyxy, (2.0, 2.0, 6.0, 6.0))
        self.assertEqual(int(instances[0].mask.sum()), 16)

    def test_decodes_predictions_last_layout(self):
        instances = decode_yolo_seg(
            synthetic_outputs("predictions_first"),
            padded_shape=(8, 8),
            roi_shape=(8, 8),
            config=InferenceConfig(),
        )
        self.assertEqual(len(instances), 1)
        self.assertAlmostEqual(instances[0].confidence, 0.90, places=5)

    def test_nms_suppresses_duplicate_boxes(self):
        instances = decode_yolo_seg(
            synthetic_outputs(duplicate=True),
            padded_shape=(8, 8),
            roi_shape=(8, 8),
            config=InferenceConfig(),
        )
        self.assertEqual(len(instances), 1)

    def test_returns_empty_for_all_low_confidence_predictions(self):
        outputs = synthetic_outputs()
        outputs[0][:, 4, :] = 0.01
        instances = decode_yolo_seg(outputs, (8, 8), (8, 8), InferenceConfig())
        self.assertEqual(instances, [])


if __name__ == "__main__":
    unittest.main()
