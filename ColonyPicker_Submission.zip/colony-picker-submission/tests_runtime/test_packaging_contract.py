import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class PackagingContractTests(unittest.TestCase):
    def test_spec_bundles_model_and_builds_windowed_onefile(self):
        text = (ROOT / "ColonyPicker.spec").read_text(encoding="utf-8")
        self.assertIn("assets/best.onnx", text)
        self.assertIn("console=False", text)
        self.assertIn("COLLECT", text)
        self.assertNotIn("COLLECT(exe", text)

    def test_powershell_builds_and_smokes_onedir_before_onefile(self):
        text = (ROOT / "scripts/build_windows.ps1").read_text(encoding="utf-8")
        onedir = text.index("--onedir")
        first_smoke = text.index("--smoke", onedir)
        onefile = text.index("ColonyPicker.spec", first_smoke)
        second_smoke = text.index("--smoke", onefile)
        self.assertLess(onedir, first_smoke)
        self.assertLess(first_smoke, onefile)
        self.assertLess(onefile, second_smoke)
        self.assertIn("SystemRoot", text)

    def test_workflow_uses_windows_and_uploads_exe(self):
        text = (ROOT / ".github/workflows/build-windows.yml").read_text(encoding="utf-8")
        self.assertIn("windows-latest", text)
        self.assertIn("unittest discover", text)
        self.assertIn("check_runtime_imports.py", text)
        self.assertIn("build_windows.ps1", text)
        self.assertIn("dist/ColonyPicker.exe", text)
        self.assertIn("upload-artifact", text)

    def test_runtime_requirements_exclude_training_frameworks(self):
        text = (ROOT / "requirements-runtime.txt").read_text(encoding="utf-8").lower()
        self.assertNotIn("torch", text)
        self.assertNotIn("ultralytics", text)
        self.assertIn("onnxruntime", text)
        self.assertIn("opencv-python-headless", text)


if __name__ == "__main__":
    unittest.main()
