import unittest

import cv2
import numpy as np

from colony_picker.preprocess import PlateROI, detect_plate_roi, prepare_input


class PreprocessRuntimeTests(unittest.TestCase):
    def test_hough_detects_centered_plate(self):
        image = np.zeros((600, 800, 3), dtype=np.uint8)
        cv2.circle(image, (400, 300), 250, (220, 220, 220), 8)
        cv2.circle(image, (400, 300), 240, (80, 80, 80), -1)

        roi = detect_plate_roi(image)

        self.assertTrue(roi.detected)
        self.assertLess(abs(roi.center_x - 400), 15)
        self.assertLess(abs(roi.center_y - 300), 15)
        self.assertLess(abs(roi.radius - 250), 20)

    def test_blank_image_uses_recorded_fallback(self):
        image = np.zeros((300, 500, 3), dtype=np.uint8)
        roi = detect_plate_roi(image)
        self.assertFalse(roi.detected)
        self.assertEqual(roi.method, "full_image_fallback")
        self.assertEqual((roi.x, roi.y, roi.width, roi.height), (0, 0, 500, 300))

    def test_preparation_only_pads_bottom_and_right(self):
        image = np.zeros((101, 130, 3), dtype=np.uint8)
        image[0, 0] = (10, 20, 30)
        roi = PlateROI(0, 0, 130, 101, 65.0, 50.0, 49.0, False, "test")

        prepared = prepare_input(image, roi, stride=32)

        self.assertEqual(prepared.roi_image.shape, (101, 130, 3))
        self.assertEqual(prepared.padded_image.shape, (128, 160, 3))
        self.assertEqual((prepared.pad_bottom, prepared.pad_right), (27, 30))
        self.assertEqual(prepared.tensor.shape, (1, 3, 128, 160))
        np.testing.assert_allclose(prepared.tensor[0, :, 0, 0], np.array([30, 20, 10]) / 255.0)

    def test_aligned_shape_receives_no_padding(self):
        image = np.zeros((64, 96, 3), dtype=np.uint8)
        roi = PlateROI(0, 0, 96, 64, 48.0, 32.0, 31.0, False, "test")
        prepared = prepare_input(image, roi)
        self.assertEqual((prepared.pad_bottom, prepared.pad_right), (0, 0))
        self.assertEqual(prepared.padded_image.shape[:2], (64, 96))

    def test_roi_mapping_returns_original_coordinates(self):
        image = np.zeros((200, 300, 3), dtype=np.uint8)
        roi = PlateROI(70, 20, 100, 120, 120.0, 80.0, 50.0, True, "hough")
        prepared = prepare_input(image, roi)
        mask = np.zeros((120, 100), dtype=np.uint8)
        mask[10:20, 30:40] = 1

        mapped = prepared.mask_to_original(mask)

        self.assertEqual(prepared.point_to_original((35, 15)), (105, 35))
        self.assertEqual(mapped.shape, (200, 300))
        self.assertEqual(int(mapped[30:40, 100:110].sum()), 100)


if __name__ == "__main__":
    unittest.main()
