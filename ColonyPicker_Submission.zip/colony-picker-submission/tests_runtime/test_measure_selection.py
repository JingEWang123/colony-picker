import dataclasses
import math
import unittest

import cv2
import numpy as np

from colony_picker.config import SelectionConfig
from colony_picker.measure import ColonyInstance, measure_instances
from colony_picker.postprocess import RawInstance
from colony_picker.preprocess import PlateROI
from colony_picker.selection import evaluate_instances


class MeasureSelectionTests(unittest.TestCase):
    def setUp(self):
        self.roi = PlateROI(100, 200, 100, 100, 150.0, 250.0, 48.0, True, "test")

    def test_circle_metrics_pick_point_and_original_offset(self):
        mask = np.zeros((100, 100), dtype=np.uint8)
        cv2.circle(mask, (50, 50), 10, 1, -1)
        raw = RawInstance((40, 40, 61, 61), 0.9, mask)

        measured = measure_instances([raw], self.roi)[0]

        self.assertGreater(measured.area, 270)
        self.assertAlmostEqual(measured.equivalent_radius, math.sqrt(measured.area / math.pi), places=5)
        self.assertGreater(measured.circularity, 0.80)
        self.assertGreater(measured.solidity, 0.90)
        self.assertEqual(measured.pick_point, (150, 250))
        self.assertGreater(measured.inner_radius, 9.0)
        self.assertGreater(measured.plate_edge_clearance, 36.0)

    def test_nearest_colony_clearance_is_computed(self):
        masks = []
        for center in ((30, 50), (70, 50)):
            mask = np.zeros((100, 100), dtype=np.uint8)
            cv2.circle(mask, center, 5, 1, -1)
            masks.append(mask)
        raw = [
            RawInstance((25, 45, 36, 56), 0.9, masks[0]),
            RawInstance((65, 45, 76, 56), 0.9, masks[1]),
        ]
        measured = measure_instances(raw, self.roi)
        self.assertGreater(measured[0].nearest_colony_clearance, 28.0)
        self.assertLess(measured[0].nearest_colony_clearance, 31.0)

    def test_pick_point_is_taken_from_largest_connected_component(self):
        mask = np.zeros((100, 100), dtype=np.uint8)
        cv2.rectangle(mask, (10, 20), (50, 23), 1, -1)
        cv2.circle(mask, (80, 80), 4, 1, -1)
        raw = RawInstance((0, 0, 100, 100), 0.9, mask)

        measured = measure_instances([raw], self.roi)[0]

        self.assertLess(measured.pick_point[0], 160)
        self.assertLess(measured.pick_point[1], 240)

    def test_rules_record_all_rejection_reasons(self):
        base = ColonyInstance.for_test(
            confidence=0.2,
            area=10,
            plate_edge_clearance=2,
            nearest_colony_clearance=1,
            inner_radius=1,
            circularity=0.2,
            solidity=0.5,
        )
        result = evaluate_instances([base], SelectionConfig())[0]
        self.assertEqual(
            set(result.reasons),
            {
                "low_confidence",
                "too_small",
                "plate_edge",
                "too_close",
                "inner_safe_area",
                "suspected_merged_circularity",
                "suspected_merged_solidity",
            },
        )
        self.assertFalse(result.pickable)
        self.assertEqual(result.pick_score, 0.0)

    def test_pickable_instances_are_sorted_by_score(self):
        low = ColonyInstance.for_test(confidence=0.5, circularity=0.8, solidity=0.9)
        high = dataclasses.replace(low, confidence=0.95, inner_radius=9.0)
        results = evaluate_instances([low, high], SelectionConfig())
        self.assertTrue(all(item.pickable for item in results))
        self.assertGreater(results[0].pick_score, results[1].pick_score)
        self.assertEqual([item.id for item in results], [1, 2])


if __name__ == "__main__":
    unittest.main()
