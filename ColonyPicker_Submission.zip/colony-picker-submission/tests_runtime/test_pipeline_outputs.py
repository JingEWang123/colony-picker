import csv
import dataclasses
import json
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from colony_picker.pipeline import analyze_batch
from colony_picker.measure import ColonyInstance
from colony_picker.postprocess import RawInstance
from colony_picker.visualize import label_font_scale, render_result


class FakeSegmenter:
    def predict(self, prepared):
        height, width = prepared.roi_image.shape[:2]
        mask = np.zeros((height, width), dtype=np.uint8)
        center = (width // 2, height // 2)
        cv2.circle(mask, center, 10, 1, -1)
        return [RawInstance((center[0] - 11, center[1] - 11, center[0] + 11, center[1] + 11), 0.95, mask)]


def write_plate(path: Path):
    image = np.full((300, 300, 3), 20, dtype=np.uint8)
    cv2.circle(image, (150, 150), 135, (200, 200, 200), 5)
    cv2.circle(image, (150, 150), 128, (100, 100, 100), -1)
    cv2.imwrite(str(path), image)


class PipelineOutputTests(unittest.TestCase):
    def test_visualization_uses_required_colors_and_reduces_dense_label_size(self):
        accepted_contour = np.array([[[5, 5]], [[30, 5]], [[30, 30]], [[5, 30]]], dtype=np.int32)
        rejected_contour = np.array([[[60, 60]], [[90, 60]], [[90, 90]], [[60, 90]]], dtype=np.int32)
        accepted = dataclasses.replace(
            ColonyInstance.for_test(), id=1, pickable=True, pick_score=90, contour=accepted_contour,
            box_xyxy=(5, 5, 30, 30), pick_point=(10, 10)
        )
        rejected = dataclasses.replace(
            ColonyInstance.for_test(), id=2, contour=rejected_contour, box_xyxy=(60, 60, 90, 90),
            pick_point=(70, 70), reasons=["too_close"]
        )
        rendered = render_result(np.zeros((100, 100, 3), dtype=np.uint8), [accepted, rejected])
        self.assertGreater(int(rendered[20, 20, 1]), int(rendered[20, 20, 2]))
        self.assertGreater(int(rendered[80, 80, 2]), int(rendered[80, 80, 1]))
        self.assertEqual(tuple(rendered[10, 10]), (0, 255, 255))
        self.assertLess(label_font_scale((3000, 3000), 120), label_font_scale((3000, 3000), 10))

    def test_batch_writes_original_coordinate_json_png_and_csv(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "plate.jpg"
            write_plate(source)
            output = root / "output"

            results = analyze_batch([source], output, FakeSegmenter())

            self.assertEqual(len(results), 1)
            self.assertEqual(results[0].status, "ok")
            payload = json.loads((output / "plate" / "result.json").read_text())
            self.assertEqual(payload["original_size"], [300, 300])
            self.assertEqual(payload["colony_count"], 1)
            x, y = payload["instances"][0]["pick_point"]
            self.assertTrue(0 <= x < 300 and 0 <= y < 300)
            polygon = payload["instances"][0]["polygon"]
            self.assertGreaterEqual(len(polygon), 3)
            self.assertTrue(all(0 <= px < 300 and 0 <= py < 300 for px, py in polygon))
            rendered = cv2.imread(str(output / "plate" / "result.png"))
            self.assertEqual(rendered.shape, (300, 300, 3))
            with (output / "summary.csv").open(newline="", encoding="utf-8-sig") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(rows[0]["status"], "ok")
            self.assertEqual(rows[0]["colony_count"], "1")

    def test_missing_image_is_recorded_without_stopping_batch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            valid = root / "valid.png"
            write_plate(valid)
            results = analyze_batch([root / "missing.jpg", valid], root / "output", FakeSegmenter())
            self.assertEqual([item.status for item in results], ["error", "ok"])
            self.assertTrue((root / "output" / "summary.csv").is_file())

    def test_duplicate_stems_get_distinct_output_folders(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            first = root / "a" / "plate.jpg"
            second = root / "b" / "plate.jpg"
            first.parent.mkdir()
            second.parent.mkdir()
            write_plate(first)
            write_plate(second)
            results = analyze_batch([first, second], root / "output", FakeSegmenter())
            self.assertNotEqual(results[0].output_dir, results[1].output_dir)
            self.assertTrue(all((item.output_dir / "result.json").is_file() for item in results))

    def test_zero_detections_still_writes_valid_outputs(self):
        class EmptySegmenter:
            def predict(self, prepared):
                return []

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "empty.png"
            write_plate(source)
            result = analyze_batch([source], root / "output", EmptySegmenter())[0]
            payload = json.loads(result.result_json.read_text())
            self.assertEqual((payload["colony_count"], payload["pickable_count"]), (0, 0))
            self.assertTrue(result.result_image.is_file())


if __name__ == "__main__":
    unittest.main()
