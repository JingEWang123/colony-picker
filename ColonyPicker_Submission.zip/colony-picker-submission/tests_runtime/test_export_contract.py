import ast
import unittest
from pathlib import Path

import onnxruntime as ort


ROOT = Path(__file__).resolve().parents[1]


class ExportContractTests(unittest.TestCase):
    def test_runtime_source_does_not_import_training_frameworks(self):
        forbidden = {"torch", "ultralytics"}
        offenders = []
        for path in [ROOT / "app.py", *sorted((ROOT / "colony_picker").glob("*.py"))]:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            for node in ast.walk(tree):
                names = []
                if isinstance(node, ast.Import):
                    names = [alias.name.split(".")[0] for alias in node.names]
                elif isinstance(node, ast.ImportFrom) and node.module:
                    names = [node.module.split(".")[0]]
                if forbidden.intersection(names):
                    offenders.append(str(path))
        self.assertEqual(offenders, [])

    def test_exported_model_has_dynamic_spatial_input_and_two_outputs(self):
        model_path = ROOT / "assets" / "best.onnx"
        self.assertTrue(model_path.is_file())
        session = ort.InferenceSession(str(model_path), providers=["CPUExecutionProvider"])
        dimensions = session.get_inputs()[0].shape
        self.assertTrue(dimensions[0] == 1 or isinstance(dimensions[0], str))
        self.assertIsInstance(dimensions[2], str)
        self.assertIsInstance(dimensions[3], str)
        self.assertEqual(len(session.get_outputs()), 2)


if __name__ == "__main__":
    unittest.main()
