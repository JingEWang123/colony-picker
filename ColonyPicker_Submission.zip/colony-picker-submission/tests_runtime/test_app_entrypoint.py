import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from colony_picker.__main__ import main
from colony_picker.gui import normalize_input_paths, parse_drop_files


class AppEntrypointTests(unittest.TestCase):
    def test_drag_payload_parses_quoted_paths_and_filters_extensions(self):
        payload = r'{C:/images/plate one.jpg} C:/images/two.png C:/images/readme.txt'
        paths = parse_drop_files(payload)
        self.assertEqual(paths, [Path("C:/images/plate one.jpg"), Path("C:/images/two.png")])

    def test_input_paths_are_deduplicated_case_insensitively(self):
        paths = normalize_input_paths(["C:/A/Plate.JPG", "c:/a/plate.jpg", "C:/A/other.PNG"])
        self.assertEqual(len(paths), 2)

    def test_smoke_loads_model_without_creating_gui(self):
        with tempfile.TemporaryDirectory() as tmp:
            model = Path(tmp) / "best.onnx"
            model.write_bytes(b"fake")
            with patch("colony_picker.__main__.OnnxSegmenter") as segmenter, patch(
                "colony_picker.__main__.launch_gui"
            ) as launch:
                code = main(["--smoke", "--model", str(model)])
            self.assertEqual(code, 0)
            segmenter.assert_called_once()
            launch.assert_not_called()


if __name__ == "__main__":
    unittest.main()
