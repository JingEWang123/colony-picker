# ColonyPicker

YOLO11n-seg 单类别菌落实例分割与挑取点推荐桌面程序。程序先用霍夫圆定位培养皿，以原始像素尺度裁出 ROI，只在右侧和底部补齐到 stride 32，再通过 CPU ONNX Runtime 做动态尺寸全图推理。运行环境不依赖 PyTorch 或 Ultralytics。

## Windows 直接运行

从 GitHub Actions 的 `ColonyPicker-windows-x64` 构建产物中下载 `ColonyPicker.exe`。拖入或选择 JPG/PNG，点击“开始分析”。输出位于 `文档/ColonyPicker_Output/<时间戳>`：每张图片包含 `result.png`、`result.json`，批次根目录包含 `summary.csv`。

## Python 运行

使用 64 位 Python 3.11（需包含 Tkinter）：

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python -m colony_picker --smoke
.venv\Scripts\python app.py
```

运行时依赖只有 `numpy`、`opencv-python-headless`、`onnxruntime`、`tkinterdnd2`；`tkinter` 随标准 Python 安装。

## 方法与输出

`assets/best.onnx` 是从最佳 YOLO11n-seg 权重导出的 dynamic ONNX。后处理直接解码框、类别置信度、mask coefficients 和 prototype masks，并把所有坐标映射回输入原图。

每个实例保存 `confidence`、`area`、`equivalent_radius`、`circularity`、`solidity`、`plate_edge_clearance`、`nearest_colony_clearance`、`pick_point`、`inner_radius`、轮廓、多项筛选原因与 `pick_score`。绿色表示推荐，红色表示拒绝，黄色点表示挑取点。

简单规则过滤低置信度、过小、靠培养皿边缘、与邻近菌落过近、内部安全半径过小及疑似粘连实例。阈值集中在 `colony_picker/config.py`，便于根据设备和培养基调整。

## 训练复现

原始数据不随仓库重复发布。将已裁剪的 `image/` 和 `mask/` 放在同一数据根目录后运行：

```bash
python -m pip install -r requirements-training.txt
python scripts/prepare_colony_dataset.py /path/to/cropped datasets/colony_patches
python scripts/train_colony_seg.py --epochs 60 --batch 2 --roi-dir /path/to/cropped/image
```

划分与参数见 `training/dataset_split.json` 和 `training/training_parameters.yaml`：17 张原图训练、1 张原图验证，先按原图划分再生成 1024 patch；两张超密集图只做 hard-case 推理。训练增强仅包含水平/垂直翻转、轻微亮度/对比度和 0.8–1.2 scale。

仓库保留 `models/best.pt` 以便重新导出：

```bash
python -m pip install -r requirements-export.txt
python scripts/export_onnx.py
```

## Windows EXE 构建

```powershell
.venv\Scripts\python -m pip install -r requirements-build.txt
powershell -ExecutionPolicy Bypass -File scripts\build_windows.ps1
```

脚本先生成并验证 onedir，再生成 windowed onefile：`dist/ColonyPicker.exe`。`.github/workflows/build-windows.yml` 会在 `windows-latest` 执行相同流程并上传 EXE。

## 验证与结果

```bash
python -m unittest discover -s tests_runtime -v
python scripts/check_runtime_imports.py
```

保存的纯 ONNX Runtime 全分辨率验证结果：

| 图像 | 用途 | 检出 | 推荐 |
| --- | --- | ---: | ---: |
| image_20 | validation | 18 | 18 |
| image_01 | dense hard case | 113 | 87 |
| image_02 | dense hard case | 3 | 3 |

`examples/` 包含上述三张图的压缩可视化预览、完整 JSON 与汇总 CSV。`image_02` 的极小密集菌落与训练分布差异较大，是当前主要失败案例；下一步应补充同尺度标注并重新训练，而不是仅降低置信度阈值。

## 仓库结构

```text
assets/best.onnx          动态 ONNX，打包进入 EXE
models/best.pt            最佳训练权重，仅用于复现导出
colony_picker/            预处理、推理、后处理、测量、GUI
scripts/                  数据准备、训练、导出、Windows 构建
tests_runtime/            运行时与打包契约测试
training/                 固定划分与训练参数
examples/                 可视化及结构化示例输出
```
