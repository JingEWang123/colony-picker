#!/usr/bin/env python3
from __future__ import annotations

import shutil
from pathlib import Path

import onnx
from ultralytics import YOLO


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    checkpoint = ROOT / "models" / "best.pt"
    destination = ROOT / "assets" / "best.onnx"
    destination.parent.mkdir(parents=True, exist_ok=True)
    model = YOLO(str(checkpoint))
    exported = Path(
        model.export(
            format="onnx",
            imgsz=1024,
            batch=1,
            dynamic=True,
            opset=17,
            simplify=False,
            half=False,
            nms=False,
            device="cpu",
        )
    )
    if exported.resolve() != destination.resolve():
        shutil.copy2(exported, destination)
    onnx.checker.check_model(onnx.load(str(destination), load_external_data=False))
    print(destination)


if __name__ == "__main__":
    main()
