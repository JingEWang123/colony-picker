#!/usr/bin/env python3
from __future__ import annotations

import ast
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FORBIDDEN = {"torch", "ultralytics"}


def main() -> None:
    offenders = []
    paths = [ROOT / "app.py", *sorted((ROOT / "colony_picker").glob("*.py"))]
    for path in paths:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            names = []
            if isinstance(node, ast.Import):
                names = [alias.name.split(".")[0] for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module.split(".")[0]]
            if FORBIDDEN.intersection(names):
                offenders.append(path)
                break
    if offenders:
        raise SystemExit("Forbidden runtime imports: " + ", ".join(str(path) for path in offenders))
    print(f"Runtime import audit OK: {len(paths)} files")


if __name__ == "__main__":
    main()
