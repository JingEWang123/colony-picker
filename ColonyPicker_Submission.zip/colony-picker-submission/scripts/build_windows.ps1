$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot

function Invoke-CleanRuntimeSmoke {
    param(
        [Parameter(Mandatory = $true)][string]$Executable,
        [Parameter(Mandatory = $true)][string]$Arguments
    )
    $SavedPath = $env:PATH
    $SavedPythonHome = $env:PYTHONHOME
    $SavedPythonPath = $env:PYTHONPATH
    try {
        $env:PATH = "$env:SystemRoot\System32;$env:SystemRoot"
        Remove-Item Env:PYTHONHOME -ErrorAction SilentlyContinue
        Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue
        $Process = Start-Process -FilePath $Executable -ArgumentList $Arguments -Wait -PassThru
        if ($Process.ExitCode -ne 0) {
            throw "Packaged smoke test failed with exit code $($Process.ExitCode): $Executable"
        }
    }
    finally {
        $env:PATH = $SavedPath
        if ($null -ne $SavedPythonHome) { $env:PYTHONHOME = $SavedPythonHome }
        if ($null -ne $SavedPythonPath) { $env:PYTHONPATH = $SavedPythonPath }
    }
}

Remove-Item -Recurse -Force build, dist -ErrorAction SilentlyContinue

python -m PyInstaller --noconfirm --clean --name ColonyPicker --onedir --windowed `
    --add-data "assets/best.onnx;assets" `
    --collect-all tkinterdnd2 `
    --collect-all onnxruntime `
    app.py

Invoke-CleanRuntimeSmoke (Resolve-Path "dist\ColonyPicker\ColonyPicker.exe") "--smoke"

Remove-Item -Recurse -Force build -ErrorAction SilentlyContinue
python -m PyInstaller --noconfirm --clean ColonyPicker.spec

Invoke-CleanRuntimeSmoke (Resolve-Path "dist\ColonyPicker.exe") "--smoke"
Write-Host "Build complete: dist\ColonyPicker.exe"
