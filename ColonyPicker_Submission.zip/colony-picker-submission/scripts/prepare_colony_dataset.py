#!/usr/bin/env python3
"""Create leak-free 1024px YOLO segmentation patches from cropped ROI images."""

from __future__ import annotations

import argparse
import json
import random
import shutil
from pathlib import Path

import cv2
import numpy as np
import yaml


TRAIN_STEMS = [f"image_{index:02d}" for index in range(3, 20)]
VAL_STEMS = ["image_20"]
HARDCASE_STEMS = ["image_01", "image_02"]


def grid_origins(length: int, patch_size: int) -> list[int]:
    """Return non-resizing patch origins that cover an axis through its far edge."""
    if length <= patch_size:
        return [0]
    origins = list(range(0, length - patch_size + 1, patch_size))
    final_origin = length - patch_size
    if origins[-1] != final_origin:
        origins.append(final_origin)
    return origins


def _clip_polygon(points: list[list[float]], size: int) -> list[list[float]]:
    polygon = [(float(x), float(y)) for x, y in points]
    if len(polygon) < 3:
        return []
    limit = float(size - 1)
    boundaries = (
        (lambda p: p[0] >= 0.0, lambda a, b: (0.0, a[1] + (b[1] - a[1]) * (-a[0]) / (b[0] - a[0]))),
        (lambda p: p[0] <= limit, lambda a, b: (limit, a[1] + (b[1] - a[1]) * (limit - a[0]) / (b[0] - a[0]))),
        (lambda p: p[1] >= 0.0, lambda a, b: (a[0] + (b[0] - a[0]) * (-a[1]) / (b[1] - a[1]), 0.0)),
        (lambda p: p[1] <= limit, lambda a, b: (a[0] + (b[0] - a[0]) * (limit - a[1]) / (b[1] - a[1]), limit)),
    )
    for inside, intersection in boundaries:
        if not polygon:
            return []
        clipped = []
        previous = polygon[-1]
        previous_inside = inside(previous)
        for current in polygon:
            current_inside = inside(current)
            if current_inside:
                if not previous_inside:
                    clipped.append(intersection(previous, current))
                clipped.append(current)
            elif previous_inside:
                clipped.append(intersection(previous, current))
            previous, previous_inside = current, current_inside
        polygon = clipped
    return [[round(x, 3), round(y, 3)] for x, y in polygon]


def build_patch(
    image: np.ndarray,
    polygons: list[list[list[float]]],
    *,
    x0: int,
    y0: int,
    patch_size: int,
) -> tuple[np.ndarray, list[list[list[float]]]]:
    """Crop a patch and clip every intersecting instance polygon to its bounds."""
    height, width = image.shape[:2]
    x1, y1 = min(width, x0 + patch_size), min(height, y0 + patch_size)
    patch = image[y0:y1, x0:x1].copy()
    if patch.shape[0] != patch_size or patch.shape[1] != patch_size:
        patch = cv2.copyMakeBorder(
            patch,
            0,
            patch_size - patch.shape[0],
            0,
            patch_size - patch.shape[1],
            cv2.BORDER_REFLECT_101,
        )

    clipped_polygons = []
    for polygon in polygons:
        shifted = [[float(x) - x0, float(y) - y0] for x, y in polygon]
        clipped = _clip_polygon(shifted, patch_size)
        if len(clipped) < 3:
            continue
        if cv2.contourArea(np.asarray(clipped, dtype=np.float32)) <= 1.0:
            continue
        clipped_polygons.append(clipped)
    return patch, clipped_polygons


def mild_brightness_contrast(
    image: np.ndarray,
    *,
    contrast: float,
    brightness: float,
) -> np.ndarray:
    adjusted = image.astype(np.float32) * contrast + brightness
    return np.clip(adjusted, 0, 255).astype(np.uint8)


def _read_polygons(path: Path) -> list[list[list[float]]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    polygons = []
    for item in data.get("objects", []):
        if item.get("category") != "colony":
            raise ValueError(f"Unexpected category {item.get('category')!r} in {path}")
        points = item.get("segmentation", [])
        if len(points) >= 3:
            polygons.append(points)
    return polygons


def _positive_origin(
    polygon: list[list[float]],
    width: int,
    height: int,
    patch_size: int,
    rng: random.Random,
) -> tuple[int, int]:
    points = np.asarray(polygon, dtype=np.float32)
    center_x, center_y = points.mean(axis=0)
    relative_x = rng.uniform(0.25, 0.75)
    relative_y = rng.uniform(0.25, 0.75)
    x0 = round(center_x - relative_x * patch_size)
    y0 = round(center_y - relative_y * patch_size)
    return (
        min(max(0, x0), max(0, width - patch_size)),
        min(max(0, y0), max(0, height - patch_size)),
    )


def _write_label(path: Path, polygons: list[list[list[float]]], patch_size: int) -> None:
    lines = []
    for polygon in polygons:
        coordinates = []
        for x, y in polygon:
            coordinates.extend((x / patch_size, y / patch_size))
        lines.append("0 " + " ".join(f"{value:.6f}" for value in coordinates))
    path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def prepare_dataset(
    source_dir: Path,
    output_dir: Path,
    *,
    train_stems: list[str] = TRAIN_STEMS,
    val_stems: list[str] = VAL_STEMS,
    patches_per_train_image: int = 10,
    positive_fraction: float = 0.70,
    patch_size: int = 1024,
    seed: int = 42,
) -> dict:
    source_dir = Path(source_dir)
    output_dir = Path(output_dir)
    image_source_dir = source_dir / "image" if (source_dir / "image").is_dir() else source_dir
    mask_source_dir = source_dir / "mask" if (source_dir / "mask").is_dir() else source_dir
    if set(train_stems) & set(val_stems):
        raise ValueError("Train and validation source images overlap")

    if output_dir.exists():
        shutil.rmtree(output_dir)
    for split in ("train", "val"):
        (output_dir / "images" / split).mkdir(parents=True, exist_ok=True)
        (output_dir / "labels" / split).mkdir(parents=True, exist_ok=True)

    rng = random.Random(seed)
    patch_records = []
    positive_count = round(patches_per_train_image * positive_fraction)

    for stem in train_stems:
        image_path = image_source_dir / f"{stem}.jpg"
        json_path = mask_source_dir / f"{stem}.json"
        image = cv2.imread(str(image_path))
        if image is None or not json_path.is_file():
            raise FileNotFoundError(f"Missing labeled source pair for {stem}")
        polygons = _read_polygons(json_path)
        if not polygons:
            raise ValueError(f"No colony polygons in {json_path}")
        height, width = image.shape[:2]

        modes = ["positive"] * positive_count + ["random"] * (patches_per_train_image - positive_count)
        rng.shuffle(modes)
        for index, mode in enumerate(modes):
            if mode == "positive":
                selected = rng.choice(polygons)
                x0, y0 = _positive_origin(selected, width, height, patch_size, rng)
            else:
                x0 = rng.randint(0, max(0, width - patch_size))
                y0 = rng.randint(0, max(0, height - patch_size))

            patch, clipped = build_patch(
                image,
                polygons,
                x0=x0,
                y0=y0,
                patch_size=patch_size,
            )
            if mode == "positive" and not clipped:
                raise RuntimeError(f"Positive sampling produced no colony for {stem}")
            contrast = rng.uniform(0.92, 1.08)
            brightness = rng.uniform(-8.0, 8.0)
            patch = mild_brightness_contrast(
                patch,
                contrast=contrast,
                brightness=brightness,
            )
            patch_stem = f"{stem}_p{index:03d}_{mode[:3]}"
            image_output = output_dir / "images" / "train" / f"{patch_stem}.jpg"
            label_output = output_dir / "labels" / "train" / f"{patch_stem}.txt"
            cv2.imwrite(str(image_output), patch, [cv2.IMWRITE_JPEG_QUALITY, 95])
            _write_label(label_output, clipped, patch_size)
            patch_records.append(
                {
                    "patch": patch_stem,
                    "split": "train",
                    "source": stem,
                    "sampling": mode,
                    "origin": [x0, y0],
                    "instances": len(clipped),
                    "contrast": round(contrast, 4),
                    "brightness": round(brightness, 4),
                }
            )

    for stem in val_stems:
        image_path = image_source_dir / f"{stem}.jpg"
        json_path = mask_source_dir / f"{stem}.json"
        image = cv2.imread(str(image_path))
        if image is None or not json_path.is_file():
            raise FileNotFoundError(f"Missing labeled source pair for {stem}")
        polygons = _read_polygons(json_path)
        height, width = image.shape[:2]
        patch_index = 0
        for y0 in grid_origins(height, patch_size):
            for x0 in grid_origins(width, patch_size):
                patch, clipped = build_patch(
                    image,
                    polygons,
                    x0=x0,
                    y0=y0,
                    patch_size=patch_size,
                )
                patch_stem = f"{stem}_p{patch_index:03d}_grid"
                cv2.imwrite(
                    str(output_dir / "images" / "val" / f"{patch_stem}.jpg"),
                    patch,
                    [cv2.IMWRITE_JPEG_QUALITY, 95],
                )
                _write_label(
                    output_dir / "labels" / "val" / f"{patch_stem}.txt",
                    clipped,
                    patch_size,
                )
                patch_records.append(
                    {
                        "patch": patch_stem,
                        "split": "val",
                        "source": stem,
                        "sampling": "grid",
                        "origin": [x0, y0],
                        "instances": len(clipped),
                    }
                )
                patch_index += 1

    manifest = {
        "source_dir": str(source_dir),
        "patch_size": patch_size,
        "seed": seed,
        "positive_fraction": positive_fraction,
        "patches_per_train_image": patches_per_train_image,
        "source_split": {
            "train": list(train_stems),
            "val": list(val_stems),
            "hardcase": list(HARDCASE_STEMS),
        },
        "patches": patch_records,
    }
    (output_dir / "patch_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    dataset_yaml = {
        "path": str(output_dir),
        "train": "images/train",
        "val": "images/val",
        "names": {0: "colony"},
    }
    (output_dir / "dataset.yaml").write_text(
        yaml.safe_dump(dataset_yaml, sort_keys=False, allow_unicode=True),
        encoding="utf-8",
    )
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--patches-per-train-image", type=int, default=10)
    parser.add_argument("--positive-fraction", type=float, default=0.70)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    manifest = prepare_dataset(
        args.source,
        args.output,
        patches_per_train_image=args.patches_per_train_image,
        positive_fraction=args.positive_fraction,
        seed=args.seed,
    )
    train_count = sum(p["split"] == "train" for p in manifest["patches"])
    val_count = sum(p["split"] == "val" for p in manifest["patches"])
    print(f"Prepared {train_count} train patches and {val_count} val patches")


if __name__ == "__main__":
    main()
