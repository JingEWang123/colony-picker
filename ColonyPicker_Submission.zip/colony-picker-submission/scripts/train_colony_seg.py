#!/usr/bin/env python3
"""Train YOLO11n-seg for colony instances with periodic full-resolution inference."""

from __future__ import annotations

import argparse
import gc
import json
import math
import shutil
import subprocess
import sys
from pathlib import Path

import cv2
import torch
import yaml
from ultralytics import YOLO
from ultralytics.nn.tasks import torch_safe_load


PROJECT_ROOT = Path(__file__).resolve().parents[1]
COLONY_NAMES = {0: "colony"}


def full_resolution_imgsz(image_shape: tuple[int, int], stride: int = 32) -> int:
    """Choose an inference size at or just above the original long edge."""
    return math.ceil(max(image_shape[:2]) / stride) * stride


def automatic_batch_size() -> int:
    """Use a conservative MPS batch for unified-memory Macs."""
    try:
        memory_bytes = int(subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.memsize"], text=True).strip())
    except (OSError, ValueError, subprocess.SubprocessError):
        return 2
    return 4 if memory_bytes >= 24 * 1024**3 else 2


def force_colony_names(result):
    """Keep the single class name stable in exported visualizations."""
    result.names = COLONY_NAMES.copy()
    return result


def set_checkpoint_class_name(checkpoint: Path) -> None:
    """Set the class name without discarding resume state from periodic checkpoints."""
    state, _ = torch_safe_load(str(checkpoint))
    for key in ("model", "ema"):
        network = state.get(key)
        if network is not None:
            network.names = COLONY_NAMES.copy()
    temporary = checkpoint.with_suffix(".tmp.pt")
    torch.save(state, temporary)
    temporary.replace(checkpoint)


def _save_predictions(
    checkpoint: Path,
    epoch: int,
    roi_dir: Path,
    output_dir: Path,
    stems: list[str],
) -> None:
    destination = output_dir / f"epoch_{epoch:03d}"
    destination.mkdir(parents=True, exist_ok=True)
    predictor = YOLO(str(checkpoint))
    records = []
    for stem in stems:
        source = roi_dir / f"{stem}.jpg"
        image = cv2.imread(str(source))
        if image is None:
            raise FileNotFoundError(source)
        imgsz = full_resolution_imgsz(image.shape[:2])
        result = predictor.predict(
            source=str(source),
            imgsz=imgsz,
            device="mps",
            conf=0.25,
            iou=0.7,
            retina_masks=True,
            save=False,
            verbose=False,
        )[0]
        rendered = force_colony_names(result).plot()
        if rendered.shape[:2] != image.shape[:2]:
            raise RuntimeError(f"Prediction visualization changed resolution for {source.name}")
        cv2.imwrite(str(destination / source.name), rendered, [cv2.IMWRITE_JPEG_QUALITY, 95])
        records.append(
            {
                "image": source.name,
                "original_size": [image.shape[1], image.shape[0]],
                "inference_imgsz": imgsz,
                "instances": len(result.boxes),
                "confidences": [round(float(value), 6) for value in result.boxes.conf.cpu().tolist()],
            }
        )
    (destination / "predictions.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    del predictor
    gc.collect()
    if torch.backends.mps.is_available():
        torch.mps.empty_cache()


def _periodic_callback(
    interval: int,
    roi_dir: Path,
    checkpoints_dir: Path,
    val_predictions_dir: Path,
    hardcase_predictions_dir: Path,
):
    completed: set[int] = set()

    def callback(trainer) -> None:
        epoch = trainer.epoch + 1
        if epoch in completed:
            return
        if epoch % interval != 0 and epoch != trainer.epochs:
            return
        completed.add(epoch)
        checkpoint = checkpoints_dir / f"epoch_{epoch:03d}.pt"
        checkpoints_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(trainer.last, checkpoint)
        set_checkpoint_class_name(checkpoint)
        _save_predictions(checkpoint, epoch, roi_dir, val_predictions_dir, ["image_20"])
        _save_predictions(
            checkpoint,
            epoch,
            roi_dir,
            hardcase_predictions_dir,
            ["image_01", "image_02"],
        )

    return callback


def train(epochs: int, batch: int | None, roi_dir: Path) -> None:
    root = PROJECT_ROOT
    dataset_yaml = root / "datasets" / "colony_patches" / "dataset.yaml"
    if not dataset_yaml.is_file():
        raise FileNotFoundError(f"Prepare the patch dataset first: {dataset_yaml}")
    if not torch.backends.mps.is_available():
        raise RuntimeError("Apple MPS is not available in this process")

    selected_batch = automatic_batch_size() if batch is None else batch
    run_name = "colony_yolo11n_seg"
    parameters = {
        "model": str(root / "yolo11n-seg.pt"),
        "data": str(dataset_yaml),
        "epochs": epochs,
        "imgsz": 1024,
        "batch": selected_batch,
        "device": "mps",
        "workers": 0,
        "pretrained": True,
        "single_cls": True,
        "patience": 0,
        "seed": 42,
        "deterministic": False,
        "save": True,
        "save_period": 20,
        "project": str(root / "runs"),
        "name": run_name,
        "exist_ok": True,
        "cache": "disk",
        "plots": True,
        "val": True,
        "hsv_h": 0.0,
        "hsv_s": 0.0,
        "hsv_v": 0.08,
        "degrees": 0.0,
        "translate": 0.0,
        "scale": (0.8, 1.2),
        "shear": 0.0,
        "perspective": 0.0,
        "flipud": 0.5,
        "fliplr": 0.5,
        "bgr": 0.0,
        "mosaic": 0.0,
        "mixup": 0.0,
        "cutmix": 0.0,
        "copy_paste": 0.0,
        "auto_augment": None,
        "erasing": 0.0,
    }
    (root / "training_parameters.yaml").write_text(
        yaml.safe_dump(parameters, sort_keys=False, allow_unicode=True),
        encoding="utf-8",
    )
    command = (
        "python scripts/train_colony_seg.py "
        f"--epochs {epochs} --batch {selected_batch} --roi-dir {roi_dir}\n"
    )
    (root / "TRAIN_COMMAND.txt").write_text(command, encoding="utf-8")

    model = YOLO(str(root / "yolo11n-seg.pt"))
    model.add_callback(
        "on_fit_epoch_end",
        _periodic_callback(
            20,
            roi_dir,
            root / "checkpoints",
            root / "val_predictions",
            root / "hardcase_predictions",
        ),
    )
    model.train(**parameters)

    weights_dir = root / "runs" / run_name / "weights"
    checkpoints_dir = root / "checkpoints"
    checkpoints_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(weights_dir / "best.pt", checkpoints_dir / "best.pt")
    shutil.copy2(weights_dir / "last.pt", checkpoints_dir / "last.pt")
    set_checkpoint_class_name(checkpoints_dir / "best.pt")
    set_checkpoint_class_name(checkpoints_dir / "last.pt")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--epochs", type=int, default=60)
    parser.add_argument("--batch", type=int, default=None, help="Defaults to automatic 2/4 selection")
    parser.add_argument("--roi-dir", type=Path, required=True, help="Cropped full-resolution ROI image directory")
    args = parser.parse_args()
    train(args.epochs, args.batch, args.roi_dir.resolve())


if __name__ == "__main__":
    main()
