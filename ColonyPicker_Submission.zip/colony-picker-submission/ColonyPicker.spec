# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all


tk_datas, tk_binaries, tk_hiddenimports = collect_all("tkinterdnd2")
ort_datas, ort_binaries, ort_hiddenimports = collect_all("onnxruntime")

a = Analysis(
    ["app.py"],
    pathex=[],
    binaries=tk_binaries + ort_binaries,
    datas=[("assets/best.onnx", "assets")] + tk_datas + ort_datas,
    hiddenimports=tk_hiddenimports + ort_hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["torch", "ultralytics"],
    noarchive=False,
)
pyz = PYZ(a.pure)

# Onefile uses EXE directly. The PowerShell script creates and smoke-tests the onedir COLLECT build first.
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="ColonyPicker",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

